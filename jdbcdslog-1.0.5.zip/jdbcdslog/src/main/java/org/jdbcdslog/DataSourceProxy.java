package org.jdbcdslog;

import javax.sql.DataSource;

public class DataSourceProxy extends DataSourceProxyBase implements DataSource {

	public DataSourceProxy() throws JDBCDSLogException {
		super();
	}

}
