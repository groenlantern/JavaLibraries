WARNING:  Do *not* edit the "*-attrs.xml" files by hand.  They should
be recreated (by running "ant attributes") whenever a change is made to
one of the corresponding "*-props.xml" files.
