package ch.qos.logback.core.joran.node;


public class ComponentNode {

  String classStr;

}
